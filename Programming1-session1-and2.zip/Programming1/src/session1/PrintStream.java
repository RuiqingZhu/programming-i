package session1;

public class PrintStream {

    public void printLn(String x){

    }
}
