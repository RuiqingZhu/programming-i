package finaltest;

public class Answer4 {
    public static void main(String[] str) {

        String[] words = new String[]{"goodbad", "goodgood", "1good1goobabad"};
        for (int i = 0; i < words.length; i++) {
            System.out.println("word : " + words[i] + "->"); //+ goodBad(words[i]));
        }

    }
//
//    public static Boolean goodBad(String word) {
//        return ;
//    }
//
}
