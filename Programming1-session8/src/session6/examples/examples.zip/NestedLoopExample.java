package session6.examples;

public class NestedLoopExample {
    public static void main(String[] args) {
        //loop of i
        for (int i = 1; i <= 3; i++) {
            //loop of j
            for (int j = 1; j <= 3; j++) {
                System.out.println(i + " " + j);
            }//end of j
        }//end of i

    }
}
